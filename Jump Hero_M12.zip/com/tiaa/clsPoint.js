class clsPoint{
    constructor(pX=0,pY=0,pR=0, pS=0){
        this.x=pX;
        this.y=pY;
        this.rotation=pR;
        this.spin=pS;
    }
}